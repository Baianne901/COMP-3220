# Project 1

Project 1 is a project that is done in ruby to create a search list of movies. 

  - This program takes submissions and adds them to a list
  - The list is saved to a doc
  - Its pretty cool

# Quick Start

  - This was created using repl.it (user: Baianne901)
  - I believe it can be used in Ubuntu
  - Download all the .rb files from Canvas then run main.rb

### Table of Contents
* The Project
* Running The application
* Author
* License


### Installation
Install the latest version of Ubuntu onto to your Windows operated computer. If this is not avaialble you can use the website repl.it.

Dowload the zip file from canvas and use search_controller.rb and main.rb.
It should look like this
```sh
$ ruby main.rb
```
### API
In running this program you are mainly executing the search controller class through the main.rb. Some of the methods in the class are showList(), updateList(), and SaveListToFile().

search_controller.rb
```sh
$ class SearchController

	attr_accessor :searchSuggestionList

	def initialize(search_list = [])
		#<TODO: write your code here>
    @searchSuggestionList = search_list
  	end

	def showList()
		#<TODO: write your code here>
    @searchSuggestionList
	end

	def updateList(movie_name)
		#<TODO: write your code here>
    if searchSuggestionList.include? movie_name
     searchSuggestionList.delete movie_name
     searchSuggestionList.unshift movie_name
    else 
     searchSuggestionList.unshift movie_name 
    end 
	end

	def saveListToFile()
		##### 
		#
		# 1.save updated search suggestion list to "data.txt" file 
		#
		#####
		#<TODO: write your code here>
    File.write("data.txt", searchSuggestionList)
	end

end
```
As you can see without the search_controller.rb the main file would not be able to function at all.
main.rb:
```sh
$ require_relative 'search_controller.rb'


# Initialize default list ...
defaultSearchList = ["toy story", 
						"spider man", 
						"star wars", 
						"harry potter", 
						"the hobbit", 
						"the hangover"]

# Let first search_controller get default list
controllerObject = SearchController.new(defaultSearchList)

##### 
#
# 1.create endless loop 
# 2.get an input from terminal(console)
# 3.update search suggestion list
# 4.loop should end when user write "exit"
# 5.save updated "searchSuggestionList" to "data.txt" file
#
#####
#<TODO: write your code here
loop do
 puts "search_list: #{controllerObject.showList()}"
 movie = gets.chomp
 controllerObject.updateList(movie)
 if (movie == "exit")
   break 
 end
end 

controllerObject.saveListToFile()
```

License
Auburn 

Author
Bailey Blaze